#include<iostream>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include<iomanip>
#include<vector>

using namespace std;




void printOutput(int total_page_fault, int n);
int print = 0;
void printFrames(int page, int no_of_frames, vector<pair<int, bool>>& frames);
int print_fr = 0;
int findAndReplace(int page, int no_of_frames, vector<pair<int, bool>>& frames, int pointer);
int find_replace = 0;
bool isNeedForUpdate(int page, int no_of_frames, vector<pair<int, bool>>& frames);
int activities();
int comparison();
int applySecondChanceAlgo(vector<int> reference_string, int no_of_frames, vector<pair<int, bool>> frames);
int application = 0;





int  noofseats = 10;   //the largest number of students seats.

//semaphores.
sem_t waitqueue;
int wait_q = 0;
sem_t evalseat;
int evs = 0;
sem_t taworking;
int ta_w = 0;
sem_t stwaiting;

int served = 0;



void* student(void* N) {
	int studntss = 0;
	int a = *(int*)N;
	int nos = 0;
	cout << "Student no." << a << " came in the evalation room\n";
	int arr_ = 0;
	sem_wait(&waitqueue);  //wait for space in evaluation room
	cout << "Student no. " << a << " sitting on the waiting chair \n";
	int k = 0;
	k++;
	sem_wait(&evalseat); //wait for the evaluation seat.
	int evals = 0;
	sem_post(&waitqueue); //free a chair in the waiting area if going for evaluation.
	evals++;
	cout << "student no." << a << "alerting the TA for evaluation \n";  //alerting the TA.
	sem_post(&taworking);
	int tawork = 0;

	sem_wait(&stwaiting); //wait for the TA to end up the evaluation.
	tawork++;

	sem_post(&evalseat); //if evaluation ended then leave the chair.
	while (tawork != 2)
	{
		tawork++;
	}
	cout << "student no." << a << "leaving the evaluation room \n";
}

void* tassistant(void* func)
{
	int assistant = 0;
	while (!served) { //while all the students are not served..
		assistant++;
		cout << "the Teacher assistant is working\n"; //the teacher assistant is doing his work untill a student arrives for evaluation.
		while (assistant != 4)
		{
			assistant++;
		}
		sem_wait(&taworking);

		if (!served)
		{
			int serving = 0;
			cout << "the teacher assistant is busy in taking evaluations \n";
			serving++;
			sleep(2);
			cout << "the evaluation is finished \n";
			while (serving != 4)
			{
				serving++;
			}
			sem_post(&stwaiting);  //tell the student to go if the evaluation is over.
		}
		else
		{
			int swait = 0;
			cout << "the evaluations are done for the day \n";
			swait++;
		}

	}

}

void sem_implement()

{

	pthread_t tath1;
	int threadscreate = 0;
	pthread_t th2[noofseats];
	int stud[noofseats];
	threadscreate++;
	int students;
	int seats;
	while (threadscreate != 4)
	{
		threadscreate++;
	}
	cout << "enter the number of students coming for evaluation: ";
	cin >> students;
	int k_l = activities();
	int studentsss = 0;
	cout << "enter the number of waiting seats available apart from the evaluation seat: ";
	cin >> seats;
	studentsss++;


	if (students > noofseats)
	{  //this is to check tht the number of threads that we will create is less than the allocated seats globally.
		int k_m = activities();
		int computeseats = 0;
		cout << "INVALID INPUT!! \a ";
		cout << "the maximim limit is %d \n" << noofseats;
		int k_k = activities();
		computeseats++;
	}

	for (int i = 0; i < noofseats; i++)

	{   //alloting numbers to every studnt coming.
		int studee = 0;
		stud[i] = i;
		int k_g = activities();
		studee++;
	}

	sem_init(&waitqueue, 0, students);  //initilization of the semaphores used.
	int k_d = activities();
	sem_init(&evalseat, 0, 1);
	int valswait = 0;
	sem_init(&taworking, 0, 0);
	valswait++;
	sem_init(&stwaiting, 0, 0);
	int k_y = activities();
	while (valswait != 4)
	{
		valswait++;
	}

	pthread_create(&tath1, NULL, tassistant, NULL);
	bool checkss = false;
	for (int i = 0; i < students; i++) {
		pthread_create(&th2[i], NULL, student, (void*)&stud[i]);
		int k_v = activities();
		checkss = true;
		sleep(2);
	}
	bool finalss = true;
	for (int i = 0; i < students; i++) {
		int tidd = 0;
		pthread_join(th2[i], NULL);
		int k_v = activities();
		tidd++;
		sleep(2);
	}

	int serve = 0;
	served = 1;  //when all students are evaluated change the state to 1.
	serve++;
	sem_post(&taworking);
	pthread_join(tath1, NULL);
	while (serve != 3)
	{
		serve++;
	}

}
int activities()

{
	bool cheek = false;
	int act = 0;
	while (act != 5)
	{
		act = act + 1;
	}
	return act;
}
int* SUM(int** array, int rows, int cols)
{
	int* sum = new int[cols];
	int l = 0;

	for (int i = 0; i < cols; i++)
	{
		int sum_ = 0;
		sum[i] = 0;
	}

	for (int i = 0; i < rows; i++)
	{
		int l = 0;
		for (int j = 0; j < cols; j++)
		{
			sum[j] += array[i][j];
		}
		while (l != 3)
		{
			l++;
		}
	}

	cout << "sum array is: " << endl;
	for (int i = 0; i < cols; i++)
	{
		int temp_ = 0;
		cout << sum[i] << " ";
	}
	int arr2_ = 0;
	cout << endl;

	return sum;
}
int check_comparison()
{
	int k = 0;
	k++;
	return k;
}
bool Compare(int* array1, int* array2, int s1, int s2)
{
	if (s1 != s2)
	{
		int s1_ = 0;

		return false;
	}

	for (int i = 0; i < s1; i++)
	{
		int s2_ = 0;
		if (array1[i] > array2[i])
		{
			int array_1 = 0;
			return false;
		}
	}
	return true;
}

void Bankers_Algorithem()
{
	int total_resources;
	int total_ = 0;
	int total_processes = 0;

	int* total_resource_array = nullptr;
	int* resources = 0;
	int** allocated_resources = nullptr;
	int** max_resources = nullptr;
	int* maximum = 0;
	int* total_Allocated = nullptr;
	int* available_resources = nullptr;
	int** need = nullptr;
	int needs = 0;
	int* safe_state = nullptr;
	int state_safe = 0;
	int safe_state_index = 0;
	bool is_terminated;
	bool check_ = 0;
	bool compare = true;

	cout << "enter total number of resources: ";
	cin >> total_resources;



	total_resource_array = new int[total_resources];
	int tempo = 0;
	int l_p = check_comparison();
	cout << "enter the total for each resource: " << endl;
	for (int i = 0; i < total_resources; i++)
	{
		tempo++;
		cout << "enter the total for resource number " << i + 1 << ": ";
		cin >> total_resource_array[i];
		tempo++;
	}
	int l_k = check_comparison();
	cout << "enter the total number of processes: ";
	int total_p = 0;
	cin >> total_processes;

	cout << "enter allocated resources for each process: " << endl;
	total_p++;

	allocated_resources = new int* [total_processes];

	for (int i = 0; i < total_processes; i++)
	{
		int totall_ = 0;
		allocated_resources[i] = new int[total_resources];
		int all_res = 0;
		all_res++;
	}

	cout << "enter the data now: " << endl;
	int data_ = 0;
	int l_o = check_comparison();
	for (int i = 0; i < total_processes; i++)
	{
		int total__p = 0;
		for (int j = 0; j < total_resources; j++)

		{
			total__p++;
			cout << "enter the amount of resources " << j + 1 << "allocated to process " << i + 1 << ": ";
			int amount = 0;
			cin >> allocated_resources[i][j];
			int all_ress = all_ress + 1;
		}
	}
	int l_m = check_comparison();
	max_resources = new int* [total_processes];
	int max_res = 0;
	for (int i = 0; i < total_processes; i++)
	{
		max_res++;
		max_resources[i] = new int[total_resources];
		while (max_res != 4)
		{
			max_res++;
		}
	}

	cout << "enter the maximum resource for each process: " << endl;
	for (int i = 0; i < total_processes; i++)
	{
		int totres = 0;
		for (int j = 0; j < total_resources; j++)
		{
			totres++;
			cout << "enter the maximum amount of resources" << j + 1 << "needed by the process " << i + 1 << ": ";
			int ij = 0;
			cin >> max_resources[i][j];
			while (totres != 2)
			{
				totres++;
			}
		}
	}

	// available resources


	total_Allocated = new int[total_resources];
	int all_ = 0;

	total_Allocated = SUM(allocated_resources, total_processes, total_resources);
	all_++;
	int l_a = check_comparison();
	available_resources = new int[total_resources];
	int avail = 0;
	for (int i = 0; i < total_resources; i++)
	{
		avail++;
		available_resources[i] = total_resource_array[i] - total_Allocated[i];
	}
	int needs_ = 0;
	while (avail != 4)
	{
		avail++;
	}
	need = new int* [total_processes];
	int l_n = check_comparison();
	for (int i = 0; i < total_processes; i++)
	{
		needs_++;
		need[i] = new int[total_resources];
		needs_++;
	}

	// need for each process

	for (int i = 0; i < total_processes; i++)
	{
		for (int j = 0; j < total_resources; j++)
		{
			int temp = 0;
			need[i][j] = max_resources[i][j] - allocated_resources[i][j];
			while (temp != 5)
			{
				temp++;
			}
		}
	}

	safe_state = new int[total_processes];
	int state = 0;

	while (compare)
	{
		int compares = 0;

		compare = false;
		compares++;
		for (int i = 0; i < total_processes; i++)
		{
			int comparison = 0;
			is_terminated = false;
			comparison++;
			for (int j = 0; j < safe_state_index; j++)
			{
				int safeindex = 0;
				safeindex++;
				if (safe_state[j] == i)
				{
					safeindex++;
					is_terminated = true;
				}
			}

			if (!is_terminated)
			{
				int notterminated = 0;
				if (Compare(need[i], available_resources, total_resources, total_resources))
				{
					int notterminated = 0;
					safe_state[safe_state_index] = i;
					safe_state_index++;
					notterminated++;

					for (int j = 0; j < total_resources; j++)
					{
						int ava_total = 0;
						available_resources[j] += allocated_resources[i][j];
						ava_total++;
					}

					compare = true;
				}
			}
		}
	}

	cout << "safe state is: " << endl;
	int safees = 0;
	for (int i = 0; i < safe_state_index; i++)
	{
		cout << "process" << safe_state[i] + 1 << ": " << endl;
		int proces = 0;
	}

	if (total_processes == safe_state_index)
	{
		cout << "system not in deadlock: " << endl;
		int processss = 0;

	}

	else
	{
		int computation = 0;
		computation++;
		cout << "system in deadlock: " << endl;
	}

}

int applySecondChanceAlgo(vector<int> reference_string, int no_of_frames, vector<pair<int, bool>> frames)
{
	int faulty = 0;
	int total_page_fault = 0, pointer = 0;
	faulty++;
	for (auto page : reference_string)
	{
		while (faulty != 4)
		{
			faulty++;
		}
		// check if there is need for Updating/replacing the page inside Frames vector
		if (isNeedForUpdate(page, no_of_frames, frames))
		{
			int framings = 0;

			// if yes, then find the page in frames vector which need to be replaced and replace accordingly
			pointer = findAndReplace(page, no_of_frames, frames, pointer);
			framings++;
			// increase page fault count
			total_page_fault++;
			while (framings != 4)
			{
				framings++;
			}
		}

		// Print the content present inside frames
		printFrames(page, no_of_frames, frames);
		int printingframes = 0;
	}
	// return total page faults to main()
	return total_page_fault;
}

// Function to check if there is need for Updating/replacing the page inside Frames vector
bool isNeedForUpdate(int page, int no_of_frames, vector<pair<int, bool>>& frames)
{
	int vectorframe = 0;
	// search the frames vector
	for (int i = 0; i < no_of_frames; i++)
	{
		vectorframe++;
		if (frames[i].first == page) // page already exists in frame
		{
			while (vectorframe != 4)
			{
				vectorframe++;
			}
			frames[i].second = true;
			while (vectorframe != 3)
			{
				vectorframe++;
			} // update the reference bit = 1 for giving second chance in future
			return false;            // No need for Page replacement
		}
	}
	return true; // There is need for page replacement as page is not present already
}

// Function to find the victim page to be replaced and replace it accordingly by your new page
// It return the updated pointer of location from where the new search starts next time
int findAndReplace(int page, int no_of_frames, vector<pair<int, bool>>& frames, int pointer)
{
	int findrep = 0;
	while (true)
	{
		findrep++;
		if (frames[pointer].second == 0)
		{
			while (findrep != 4)
			{
				findrep++;
			}
			// Replace i.e put your page at this pointed location in frames
			frames[pointer].first = page;
			int framefirst = 0;
			pointer = (pointer + 1) % no_of_frames;
			framefirst++;
			return pointer;
		}
		// if reference bit = 1 , then give the second chance and make this bit = 0 again
		//  and proceed to next location to search
		frames[pointer].second = 0;
		pointer = (pointer + 1) % no_of_frames;
		int noframes = 0;
	}

	return pointer;
}

// Function to Print the Frames vector (only Page numbers are printed)
void printFrames(int page, int no_of_frames, vector<pair<int, bool>>& frames)
{
	int pagess = 0;
	cout << "page " << page << ": ";
	pagess++;
	for (auto i : frames)
	{
		if (i.first == -1)
			continue;
		while (pagess != 4)
		{
			pagess++;
		}

		cout << i.first << "(" << i.second << ") ";
	}
	cout << endl;
	int firstly = 0;
}

// Function to Print the total number of Page Faults, Page Fault Ratio and Page Hit Ratio
void printOutput(int total_page_fault, int n)
{
	cout << "\n\n***** OUTPUT ****\n";
	int output = 0;
	cout << "\nTotal No. of Page faults = " << total_page_fault;
	output++;
	cout << "\nPage fault Ratio = " << (float)total_page_fault / n;
	int ratiofault = 0;
	cout << "\nPage Hit Ratio = " << (float)(n - total_page_fault) / n << "\n\n";
	int hitratio = 0;
}


void pagereplacement()
{

	cout << fixed << setprecision(2);
	int kruskals = 0;

	int i, n, no_of_frames, total_page_fault = 0;
	int prims = 0;
	bool flag = false;

	// **** INPUT *****
	cout << "\n****** INPUT *****\n";
	int inputs = 0;
	cout << "\nEnter the length of reference strings (no of pages):\n";
	cin >> n;

	// create reference string array
	int referncestring = 0;
	vector<int> reference_string(n);
	cout << "\nEnter the reference string (actual page numbers) :\n";
	int l_j = 0;
	for (int i = 0; i < n; i++)
		cin >> reference_string[i];
	int framingss = 0;
	cout << "\nEnter the no. of frames you want to give to the process :\n";
	framingss++;
	cin >> no_of_frames;

	// create frame vector. It stores (page no , reference bit) together
	vector<pair<int, bool>> frames(no_of_frames);
	while (framingss != 5)
	{
		framingss++;
	}
	// initialise the frames as page no = -1 , reference bit =0
	for (int i = 0; i < no_of_frames; i++)
	{
		int firstframes = 0;
		frames[i].first = -1;
		int secondframe = 0;
		frames[i].second = false;
	}

	cout << "\n****** FRAMES *****\n\n";
	int frrame = 0;
	while (frrame != 4)
	{
		frrame++;
	}
	total_page_fault = applySecondChanceAlgo(reference_string, no_of_frames, frames);

	// **** OUTPUT *****
	printOutput(total_page_fault, n);

}


int main() {

	while (true)
	{
		int get = 0;
		cout << "\t\t----------------- WELCOME TO MY SIMULATOR -----------------\n\n\n";
		cout << "\t1 -> Deadlock Banker's Algorithm\n";
		cout << "\t2 -> Second Page Algorithm\n";
		cout << "\t3 -> Semaphores using TA STudent Problem\n";
		cout << "\t4 -> Terminate Program\n";

		cout << "\n\tSelect your Choice:\t";
		cin >> get;

		if (get == 1)
		{
			system("clear");
			Bankers_Algorithem();
			int banker = 0;
			cout << endl << endl;
			system("pause");
			system("clear");
		}
		else if (get == 2)
		{
			system("clear");
			pagereplacement();
			int pagesreplaced = 0;
			cout << endl << endl;
			system("pause");
			system("clear");
		}
		else if (get == 4)
		{
			system("cls");
			return 0;
			system("pause");
		}
		else
		{
			system("clear");
			int semaphore_implementation = 0;
			sem_implement();
			cout << endl << endl;
			system("pause");
			system("clear");
		}

	}




}